			</div>
			<!-- /#page-wrapper -->

		</div>
		<!-- /#wrapper -->

		<!-- Metis Menu Plugin JavaScript -->
		<script src="<?php echo base_url('assets/admin/bower_components/metisMenu/dist/metisMenu.min.js');?>"></script>

		<!-- Morris Charts JavaScript -->
		<script src="<?php echo base_url('assets/admin/bower_components/raphael/raphael-min.js');?>"></script>
		<!--<script src="<?php echo base_url('assets/admin/bower_components/morrisjs/morris.min.js');?>"></script>
		
		<script src="<?php echo base_url('assets/admin/js/morris-data.js');?>"></script>-->

		<!-- Custom Theme JavaScript -->
		<script src="<?php echo base_url('assets/admin/dist/js/sb-admin-2.js');?>"></script>
		
	</body>
</html>